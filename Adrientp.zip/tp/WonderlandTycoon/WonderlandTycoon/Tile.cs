﻿using System;

namespace WonderlandTycoon
{
    public class Tile
    {
        public enum Biome
        {
            SEA, MOUNTAIN, PLAIN
        }

        private Biome biome;
        private Building building;
        
        public Biome GetBiome
        {
            get { return biome; }
        }

        public Tile(Biome b)
        {
            biome = b;
            building = null;
        }

        public bool Build(ref long money, Building.BuildingType type)
        {
            if (biome != Biome.PLAIN)
                return false;
            switch (type)
            {
                case Building.BuildingType.SHOP:
                    if (money >= Shop.BUILD_COST)
                    {
                        building = new Shop();
                        money -= Shop.BUILD_COST;
                        return true;
                    }
                    break;
                case Building.BuildingType.HOUSE:
                    if (money >= House.BUILD_COST)
                    {
                        building = new House();
                        money -= House.BUILD_COST;
                        return true;
                    }
                    break;
                case Building.BuildingType.ATTRACTION:
                    if (money >= Attraction.BUILD_COST)
                    {
                        building = new Attraction();
                        money -= Attraction.BUILD_COST;
                        return true;
                    }
                    break;
                default:
                    building = null;
                    break;
            }
            return false;
        }

        public bool Upgrade(ref long money)
        {
            if (building == null)
                return false;
            bool success = false;
            switch (building.Type)
            {
                case Building.BuildingType.SHOP:
                    success = ((Shop) building).Upgrade(ref money);
                    break;
                case Building.BuildingType.HOUSE:
                    success = ((House) building).Upgrade(ref money);
                    break;
                case Building.BuildingType.ATTRACTION:
                    success = ((Attraction) building).Upgrade(ref money);
                    break;
                default:
                    break;
            }
            return success;
        }

        public long GetHousing()
        {
            if (building == null || building.Type != Building.BuildingType.HOUSE)
                return 0;
            return ((House) building).Housing();
        }

        public long GetAttractiveness()
        {
            if (building == null || building.Type != Building.BuildingType.ATTRACTION)
                return 0;
            return ((Attraction) building).Attractiveness();
        }

        public long GetIncome(long population)
        {
            if (building == null || building.Type != Building.BuildingType.SHOP)
                return 0;
            return ((Shop) building).Income(population);
        }
        
        /*Fonction suplementaires */

        public bool isBuildable()
        {
            if (biome != Biome.PLAIN || building != null)
                return false;
            return true;
        }

        public Building Building => building;

        public Building.BuildingType GetBuildingType()
        {
            if (building == null)
                return Building.BuildingType.NONE;
            return building.Type;
        }
    }
}
