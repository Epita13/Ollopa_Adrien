﻿using System;

namespace WonderlandTycoon
{
    public class Game
    {

        private long score;
        private long money;
        private int nbRound;
        private int round;
        private Map map;

        public long Score => score;
        public long Money => money;
        public int NbRound => nbRound;
        public int Round => round;
        public Map Map => map;
        

        public Game(string name, int nbRound, long initialMoney)
        {
            TycoonIO.GameInit(name, nbRound, initialMoney);
            round = 1;
            this.nbRound = nbRound;
            map = new Map(name);
            money = initialMoney;
            score = 0;
        }

        public long Launch(Bot bot)
        {
            bot.Start(this);
            for (int i = round; i <= nbRound; i++)
            {
                bot.Update(this);
                Update();
                round++;
            }
            bot.End(this);
            return score;
        }

        public void Update()
        {
            long earnedMoney = map.GetIncome(map.GetPopulation());
            Console.WriteLine(round+" -> "+earnedMoney+ "   ("+money+")  " + map.GetCountBuildableTile()+ "  --  "+ map.GetPopulation());
            money += earnedMoney;
            score += earnedMoney;
            TycoonIO.GameUpdate();
        }

        public bool Build(int i, int j, Building.BuildingType type)
        {
            bool success = map.Build(i, j, ref money, type);
            if (!success)
                return false;
            TycoonIO.GameBuild(i, j, type);
            return true;
        }

        public bool Upgrade(int i, int j)
        {
            bool success = map.Upgrade(i, j, ref money);
            if (!success)
                return false;
            TycoonIO.GameUpgrade(i, j);
            return true;
        }
    }
}
