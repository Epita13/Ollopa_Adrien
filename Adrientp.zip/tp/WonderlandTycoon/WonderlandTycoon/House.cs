﻿using System;

namespace WonderlandTycoon
{
    public class House : Building
    {
        public const long BUILD_COST = 250;
        public static readonly long[] UPGRADE_COST = {750, 3000, 10000};
        public static readonly long[] HOUSING = {300, 500, 650, 750};

        private int lvl;
        public int Lvl => lvl;

        public House()
        {
            this.type = BuildingType.HOUSE;
            lvl = 0;
        }

        public long Housing()
        {
            return HOUSING[lvl];
        }

        public bool Upgrade(ref long money)
        {
            if (lvl >= 3 || UPGRADE_COST[lvl] > money)
                return false;
            money -= UPGRADE_COST[lvl];
            lvl++;
            return true;
        }
    }
}
