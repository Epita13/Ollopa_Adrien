﻿using System;
using System.CodeDom.Compiler;

namespace WonderlandTycoon
{
    public class Map
    {
        public Tile[,] matrix;

        public Map(string name)
        {
            matrix = TycoonIO.ParseMap(name);
        }

        public bool Build(int i, int j, ref long money,
                Building.BuildingType type)
        {
            Tile tile = matrix[i, j];
            return tile.Build(ref money, type);
        }

        public bool Upgrade(int i, int j, ref long money)
        {
            Tile tile = matrix[i, j];
            return tile.Upgrade(ref money);
        }

        public long GetAttractiveness()
        {
            long number = 0;
            foreach (Tile tile in matrix)
                number += tile.GetAttractiveness();
            return number;
        }

        public long GetHousing()
        {
            long number = 0;
            foreach (Tile tile in matrix)
                number += tile.GetHousing();
            return number;
        }

        public long GetPopulation()
        {
            long housing = GetHousing();
            long attractiveness = GetAttractiveness();
            if (housing <= attractiveness)
                return housing;
            return attractiveness;
        }

        public long GetIncome(long population)
        {
            long money = 0;
            foreach (Tile tile in matrix)
                money += tile.GetIncome(population);
            return money;
        }
        
        
        /* Fonctions suplementaire */
        public int GetCountBuildableTile()
        {
            int nb = 0;
            foreach (var tile in matrix)
            {
                if (tile.isBuildable())
                    nb++;
            }
            return nb;
        }

        public bool isBuildable()
        {
            return GetCountBuildableTile() > 0;
        }

        public int GetShopsCount()
        {
            int count = 0;
            foreach (var tile in matrix)
            {
                if (tile.GetBuildingType()==Building.BuildingType.SHOP)
                    count++;
            }
            return count;
        }
        
        public int GetHousesCount()
        {
            int count = 0;
            foreach (var tile in matrix)
            {
                if (tile.GetBuildingType()==Building.BuildingType.HOUSE)
                    count++;
            }
            return count;
        }
        
        public int GetAttractionsCount()
        {
            int count = 0;
            foreach (var tile in matrix)
            {
                if (tile.GetBuildingType()==Building.BuildingType.ATTRACTION)
                    count++;
            }
            return count;
        }

        public int[] GetBuildableTile()
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (matrix[i,j].isBuildable())
                        return new int[2] {i,j};
                }
            }
            return new int[2] {-1,-1};
        }

        public int[] GetHouseByLvl(int lvl)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (matrix[i, j].GetBuildingType() != Building.BuildingType.HOUSE)
                        continue;
                    if (((House)matrix[i, j].Building).Lvl == lvl)
                        return new int[2] {i,j};
                }
            }
            return new int[2] {-1,-1};
        }
        
        public int[] GetShopByLvl(int lvl)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (matrix[i, j].GetBuildingType() != Building.BuildingType.SHOP)
                        continue;
                    if (((Shop)matrix[i, j].Building).Lvl == lvl)
                        return new int[2] {i,j};
                }
            }
            return new int[2] {-1,-1};
        }
        
        public int[] GetAttractionByLvl(int lvl)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (matrix[i, j].GetBuildingType() != Building.BuildingType.ATTRACTION)
                        continue;
                    if (((Attraction)matrix[i, j].Building).Lvl == lvl)
                        return new int[2] {i,j};
                }
            }
            return new int[2] {-1,-1};
        }

        public int GetCountBuildingByLvlAndType(Building.BuildingType type, int lvl)
        {
            int count = 0;
            foreach (var tile in matrix)
            {
                if (tile.GetBuildingType() == type)
                {
                    if (type == Building.BuildingType.SHOP)
                        if (((Shop) tile.Building).Lvl == lvl)
                            count++;
                    if (type == Building.BuildingType.HOUSE)
                        if (((House) tile.Building).Lvl == lvl)
                            count++;
                    if (type == Building.BuildingType.ATTRACTION)
                        if (((Attraction) tile.Building).Lvl == lvl)
                            count++;
                }
            }
            return count;
        }
        
    }
}
