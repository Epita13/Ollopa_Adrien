﻿using System;
namespace WonderlandTycoon
{
    public class MyBot : Bot
    {
        private Map map;
        private int buildablePlaces;
        public override void Start(Game game)
        {
            map = game.Map;
            buildablePlaces = map.GetCountBuildableTile();
        }

        public override void Update(Game game)
        {
            long attractiveness = map.GetAttractiveness();
            long housing = map.GetHousing();

            
            bool continueB = true;
            while (map.isBuildable() && continueB)
            {
                attractiveness = map.GetAttractiveness();
                housing = map.GetHousing();
                if (attractiveness >= housing)
                {
                    if (game.Money >= House.BUILD_COST && map.GetHousesCount()<=buildablePlaces/2.5f)
                    {
                        int[] pos = map.GetBuildableTile();
                        game.Build(pos[0], pos[1], Building.BuildingType.HOUSE);
                    }
                    else
                        continueB = false;
                }
                else
                {
                    int[] attractionlvl1 = map.GetAttractionByLvl(0);
                    if (game.Money >= Attraction.UPGRADE_COST[0] && attractionlvl1[0]!=-1)
                    {
                        game.Upgrade(attractionlvl1[0], attractionlvl1[1]);
                    }
                    else if (game.Money >= Attraction.BUILD_COST)
                    {
                        int[] pos = map.GetBuildableTile();
                        game.Build(pos[0], pos[1], Building.BuildingType.ATTRACTION);
                    }
                    else
                    {
                        if (game.Money >= Shop.BUILD_COST && map.GetShopsCount()<=buildablePlaces/1.8f) // (map.GetShopsCount()/(map.GetAttractionsCount()))<=23
                        {
                            int[] pos = map.GetBuildableTile();
                            game.Build(pos[0], pos[1], Building.BuildingType.SHOP);
                        }
                        else
                            continueB = false;
                    }
                }
            }

            
            if (!map.isBuildable())
            {
                continueB = true;
                while (continueB)
                {
                    attractiveness = map.GetAttractiveness();
                    housing = map.GetHousing();
                    if (attractiveness >= housing)
                    {
                        // Upgrade House
                        bool notUpgrade = true;
                        int lvl = 0;
                        while (notUpgrade && lvl < 3)
                        {
                            int[] pos = map.GetHouseByLvl(lvl);
                            if (pos[0] != -1)
                            {
                                if (game.Money >= House.UPGRADE_COST[lvl])
                                {
                                    game.Upgrade(pos[0], pos[1]);
                                    notUpgrade = false;
                                }
                            }
                            lvl++;
                        }
                        //
                        if (notUpgrade)
                        {
                            lvl = 0;
                            while (notUpgrade && lvl < 3)
                            {
                                int[] pos = map.GetShopByLvl(lvl);
                                if (pos[0] != -1)
                                {
                                    if (game.Money >= Shop.UPGRADE_COST[lvl])
                                    {
                                        game.Upgrade(pos[0], pos[1]);
                                        notUpgrade = false;
                                    }
                                }
                                lvl++;
                            }
                        }
                        if (notUpgrade)
                            continueB = false;
                    }
                    else
                    {
                        bool notUpgrade = true;
                        int lvl = 0;
                        while (notUpgrade && lvl < 3)
                        {
                            int[] pos = map.GetAttractionByLvl(lvl);
                            if (pos[0] != -1)
                            {
                                if (game.Money >= Attraction.UPGRADE_COST[lvl])
                                {
                                    game.Upgrade(pos[0], pos[1]);
                                    notUpgrade = false;
                                }
                            }
                            lvl++;
                        }
                        if (notUpgrade)
                        {
                            lvl = 0;
                            while (notUpgrade && lvl < 3)
                            {
                                int[] pos = map.GetShopByLvl(lvl);
                                if (pos[0] != -1)
                                {
                                    if (game.Money >= Shop.UPGRADE_COST[lvl])
                                    {
                                        game.Upgrade(pos[0], pos[1]);
                                        notUpgrade = false;
                                    }
                                }
                                lvl++;
                            }
                        }
                        if (notUpgrade)
                            continueB = false;
                    }
                }
            }
            
            

        }

        public override void End(Game game)
        {
            Console.WriteLine("House : "+map.GetHousesCount());
            Console.WriteLine("Shop : "+map.GetShopsCount());
            Console.WriteLine("Attractions : "+map.GetAttractionsCount());
            Console.WriteLine(map.GetPopulation());
            Console.WriteLine(map.GetAttractiveness());
            Console.WriteLine(map.GetHousing());
        }
        
    }
}
